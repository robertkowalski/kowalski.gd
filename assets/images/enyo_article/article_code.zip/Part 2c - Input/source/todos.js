enyo.kind({
    name: "rok.Todos",
    kind: enyo.Control,
    components: [
          { style: "padding: 10px", components: [
              { tag: "input", name: "todoTextarea" },
              { tag: "button", content: "Add", ontap: "addTask" }
          ]},
          { name: "todolist" }
    ],
    create: function() {
        this.inherited(arguments);
    },
    addTask: function(inSource, inEvent) {

        if (this.$.todoTextarea.hasNode().value !== "") {
            this.createComponent({
              kind: rok.Task,
              container: this.$.todolist,
              taskDescription: this.$.todoTextarea.hasNode().value
            });
            //re-render todolist
            this.$.todolist.render();
            //reset input
            this.$.todoTextarea.hasNode().value = "";
        }
    }
});

enyo.kind({
    name: "rok.Task",
    kind: enyo.Control,
    tag: "div",
    style: "border-top: 1px solid #c6c6c6;",
    published: {
        taskDescription: ""
    },
    components: [
        { tag: "span", name: "todo" },
        { tag: "button", content: "Remove", ontap: "removeTodo", style: "margin: 10px;" }
    ],
    create: function() {
        this.inherited(arguments);
        this.todoChanged();
    },
    todoChanged: function() {
        this.$.todo.setContent(this.taskDescription); 
    },
    removeTodo: function(inSource, inEvent) {
        this.destroy();
    }
});
